"use client"

import { Phone, MapPin, Clock, CheckCircle, MessageCircle, Instagram, Facebook } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function Component() {
  const handleWhatsAppClick = () => {
    const phoneNumber = "5532984693132"
    const message = "Olá! Gostaria de saber mais sobre o Vale Salgado Semanal!"
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-center">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">🥟</span>
              </div>
              <h1 className="text-2xl font-bold text-gray-800">Vale Salgado</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="mb-8">
            <div className="w-32 h-32 mx-auto mb-6 bg-gradient-to-br from-orange-400 to-yellow-500 rounded-full flex items-center justify-center shadow-lg">
              <span className="text-6xl">🥟</span>
            </div>
          </div>

          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">Vale Salgado Semanal</h2>

          <p className="text-xl md:text-2xl text-gray-600 mb-4">Comodidade e Economia!</p>

          <p className="text-lg text-gray-700 mb-8 max-w-2xl mx-auto">
            Já pensou em garantir seu salgado do dia sem precisar se preocupar com o troco? Com o Vale Salgado Semanal,
            você paga <span className="font-bold text-orange-600">R$50</span> no início da semana e pode pegar{" "}
            <span className="font-bold text-orange-600">1 salgado por dia</span>, de segunda a sexta.
          </p>

          <div className="bg-orange-100 border-l-4 border-orange-500 p-4 mb-8 max-w-2xl mx-auto">
            <p className="text-orange-800 font-medium">
              É só chegar, mostrar seu vale e pegar seu lanche — simples assim!
            </p>
          </div>

          <Button
            onClick={handleWhatsAppClick}
            className="bg-green-500 hover:bg-green-600 text-white px-8 py-4 text-lg rounded-full shadow-lg transform hover:scale-105 transition-all duration-200"
          >
            <MessageCircle className="w-6 h-6 mr-2" />
            Fale no WhatsApp
          </Button>
        </div>
      </section>

      {/* Como Funciona */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-4xl">
          <h3 className="text-3xl font-bold text-center text-gray-800 mb-12">✅ Como Funciona</h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">💰</span>
                </div>
                <h4 className="font-bold text-lg mb-2">Valor único</h4>
                <p className="text-gray-600">R$50 por semana</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">📅</span>
                </div>
                <h4 className="font-bold text-lg mb-2">Válido</h4>
                <p className="text-gray-600">Segunda a sexta-feira</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🥟</span>
                </div>
                <h4 className="font-bold text-lg mb-2">Variedade</h4>
                <p className="text-gray-600">Coxinha, pastel, empada e mais!</p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">✅</span>
                </div>
                <h4 className="font-bold text-lg mb-2">Controle</h4>
                <p className="text-gray-600">Marcamos seu dia na cartela</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Ideal Para */}
      <section className="py-16 px-4 bg-gradient-to-r from-orange-100 to-yellow-100">
        <div className="container mx-auto max-w-4xl text-center">
          <h3 className="text-3xl font-bold text-gray-800 mb-8">Ideal para quem...</h3>

          <div className="grid md:grid-cols-3 gap-6">
            <div className="flex items-center justify-center gap-3 bg-white p-6 rounded-lg shadow-sm">
              <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
              <span className="text-lg font-medium">Trabalha</span>
            </div>
            <div className="flex items-center justify-center gap-3 bg-white p-6 rounded-lg shadow-sm">
              <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
              <span className="text-lg font-medium">Estuda</span>
            </div>
            <div className="flex items-center justify-center gap-3 bg-white p-6 rounded-lg shadow-sm">
              <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
              <span className="text-lg font-medium">Quer praticidade</span>
            </div>
          </div>
        </div>
      </section>

      {/* Localização e Contato */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-4xl">
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-4">
                  <MapPin className="w-6 h-6 text-orange-500" />
                  <h4 className="text-xl font-bold">📍 Onde retirar?</h4>
                </div>
                <p className="text-gray-700 mb-2">Rua [rua Luis Viana ]</p>
                <div className="flex items-center gap-2 text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span>Sempre das [de 8 as 19 horas]</span>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardContent className="pt-6">
                <div className="flex items-center gap-3 mb-4">
                  <Phone className="w-6 h-6 text-green-500" />
                  <h4 className="text-xl font-bold">📲 Fale com a gente</h4>
                </div>
                <p className="text-2xl font-bold text-green-600 mb-4">(32) 98469-3132</p>
                <Button onClick={handleWhatsAppClick} className="w-full bg-green-500 hover:bg-green-600 text-white">
                  <MessageCircle className="w-5 h-5 mr-2" />
                  Chamar no WhatsApp
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 px-4 bg-gradient-to-r from-orange-500 to-yellow-500 text-white">
        <div className="container mx-auto max-w-4xl text-center">
          <h3 className="text-3xl font-bold mb-4">Pronto para começar?</h3>
          <p className="text-xl mb-8 opacity-90">
            Garante já seu Vale Salgado Semanal e tenha praticidade todos os dias!
          </p>
          <Button
            onClick={handleWhatsAppClick}
            className="bg-white text-orange-600 hover:bg-gray-100 px-8 py-4 text-lg rounded-full shadow-lg transform hover:scale-105 transition-all duration-200"
          >
            <MessageCircle className="w-6 h-6 mr-2" />
            Quero meu Vale Salgado!
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">🥟</span>
              </div>
              <span className="text-xl font-bold">Vale Salgado</span>
            </div>

            <div className="flex items-center gap-4">
              <span className="text-gray-400">Siga-nos:</span>
              <div className="flex gap-3">
                <Button variant="ghost" size="sm" className="text-white hover:text-orange-400">
                  <Instagram className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="sm" className="text-white hover:text-orange-400">
                  <Facebook className="w-5 h-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-white hover:text-green-400"
                  onClick={handleWhatsAppClick}
                >
                  <MessageCircle className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-6 pt-6 text-center text-gray-400">
            <p>&copy; 2025 Vale Salgado. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
